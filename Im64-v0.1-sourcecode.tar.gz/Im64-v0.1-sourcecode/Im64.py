#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#  Copyright: GUIMish <Mish7913@gmail.com>
#  License:   GNU General Public License v2 or later

import pygtk; import gtk; import locale; import gettext; import base64

pygtk.require("2.0")

class Window:
	def __init__(self):
		self.AcG = gtk.AccelGroup(); self.UrlT = ''
		
		self.window = gtk.Window()
		self.window.set_title("Im64"); 			self.window.set_resizable(False); 		self.window.set_position(gtk.WIN_POS_CENTER);
		self.window.set_border_width(0); 		self.window.set_size_request(350, 400); self.window.set_icon(self.fileicon("Icon.svg"));
		self.window.connect("destroy", self.quit);
		
		self.vBox = gtk.VBox(False, 0); self.mMenuBar = gtk.MenuBar();
		
		self.mMenuFile = gtk.Menu(); self.mItemFile = gtk.MenuItem("File"); self.mItemFile.set_submenu(self.mMenuFile);
		self.mItemOpen = gtk.MenuItem("Open");   self.mMenuFile.append(self.mItemOpen);  self.mItemOpen.connect("activate", self.open);
		self.mItemExit = gtk.MenuItem("Exit");   self.mMenuFile.append(self.mItemExit);  self.mItemExit.connect("activate", self.quit);
		
		self.mMenuHelp = gtk.Menu();             self.mItemHelp = gtk.MenuItem("Help");  self.mItemHelp.set_submenu(self.mMenuHelp);
		self.mItemAbout = gtk.MenuItem('About'); self.mMenuHelp.append(self.mItemAbout); self.mItemAbout.connect("activate", self.about);
		
		self.mMenuBar.append(self.mItemFile); self.mMenuBar.append(self.mItemHelp); self.vBox.pack_start(self.mMenuBar, False, False, 2);
		
		self.hBox = gtk.HBox(True, 0);       self.ImageFrame = gtk.Frame();        self.hBox.add(self.ImageFrame);self.Image = gtk.Image();
		self.Image.set_size_request(35, 35); self.ImageFrame.add(self.Image);      self.hBox.set_border_width(5);
		self.vBox2 = gtk.VBox(True, 0);      self.BtnOpen = gtk.Button('Open');    self.BtnOpen.connect("clicked", self.open); 
		self.BtnGenerate = gtk.Button('Generate'); self.vBox3 = gtk.VBox(True, 0); self.hBox.add(self.vBox2); self.vBox2.add(self.BtnOpen);
		self.vBox2.add(self.vBox3); 			   self.vBox.add(self.hBox); 	   self.vBox2.add(self.BtnGenerate);
		self.hBox4 = gtk.HBox(True, 0); 		   self.vBox2.add(self.hBox4); 	   self.BtnCopy = gtk.Button('Copy');
		self.hBox4.add(self.BtnCopy); 			   self.BtnCopy.connect("clicked", self.copy);
		self.BtnClear = gtk.Button('Clear');	   self.hBox4.add(self.BtnClear);  self.BtnClear.connect("clicked", self.clear);
		
		self.ScWin = gtk.ScrolledWindow(); self.ScWin.set_policy(gtk.POLICY_AUTOMATIC, gtk.POLICY_ALWAYS); self.TextView = gtk.TextView();
		self.TextView.set_editable(False); self.TextView.set_wrap_mode(True); self.ScWin.add(self.TextView); self.vBox.add(self.ScWin);
		self.TextBuffer = self.TextView.get_buffer(); self.TextView.set_size_request(350, 145);
		
		self.BtnGenerate.connect("clicked", self.generate); self.window.add(self.vBox); self.window.show_all();
		
	def about(self, widget, data = None):
		self.abdialog = gtk.AboutDialog();
		self.abdialog.set_program_name("Im64"); 				self.abdialog.set_version("0.1");
		self.abdialog.set_logo(self.fileicon("Icon.svg"));		self.abdialog.set_authors(("GUIMish <Mish7913@gmail.com>", ""));
		self.abdialog.set_copyright("Copyright © Mish7913"); 	self.abdialog.set_comments("GNU Converter\nImages to Base64");
		self.abdialog.set_website_label("Web-site"); 			self.abdialog.set_website("https://guimish.blogspot.com/2017/03/im64.html");
		self.abdialog.set_license("Im64 - Free software. And licensed under GNU General Public License.");
		self.abdialog.run(); self.abdialog.destroy();
	def fileicon(self, file): return gtk.gdk.pixbuf_new_from_file(file);
	def open(self, widget, data = None):
		self.dialog = gtk.FileChooserDialog("Open..", None, gtk.FILE_CHOOSER_ACTION_OPEN, (gtk.STOCK_CANCEL, gtk.RESPONSE_CANCEL, 
																						   gtk.STOCK_OPEN,   gtk.RESPONSE_OK))
		self.dialog.set_default_response(gtk.RESPONSE_OK);
		self.filter = gtk.FileFilter(); self.filter.set_name("Images");
		self.filter.add_mime_type("image/png"); self.filter.add_mime_type("image/jpeg"); self.filter.add_mime_type("image/gif");
		self.filter.add_pattern("*.png"); self.filter.add_pattern("*.jpg"); self.filter.add_pattern("*.gif");
		self.filter.add_pattern("*.tif"); self.filter.add_pattern("*.xpm"); self.dialog.add_filter(self.filter);
		response = self.dialog.run();
		if response == gtk.RESPONSE_OK:
			self.Img = self.fileicon(self.dialog.get_filename()); self.UrlT = str(self.dialog.get_filename());
			if self.Img.get_width() < 150:
				if self.Img.get_height() < 150: self.Image.set_from_pixbuf(self.Img)
			else:
				if self.Img.get_width() > self.Img.get_height():
					self.height = int((float(self.Img.get_height()) / float(self.Img.get_width())) * 150)
					self.Image.set_from_pixbuf(self.Img.scale_simple(150, self.height, gtk.gdk.INTERP_BILINEAR))
				else:
					self.width = int((float(self.Img.get_width()) / float(self.Img.get_height())) * 150)
					self.Image.set_from_pixbuf(self.Img.scale_simple(self.width, 150, gtk.gdk.INTERP_BILINEAR))
		self.dialog.destroy();
	def generate(self, widget, data = None):
		self.TextBuffer.set_text('<img src="data:image/png;base64,' + base64.b64encode(open(self.UrlT, "rb").read()) + '" />');
	def copy(self, widget, data = None):
		self.btext = self.TextBuffer.get_text(self.TextBuffer.get_start_iter(), self.TextBuffer.get_end_iter(), True)
		self.clipboard = gtk.clipboard_get(); self.clipboard.set_text(self.btext); self.clipboard.store()
	def clear(self, widget, data = None): self.TextBuffer.set_text('');
	def quit(self, widget, data = None): gtk.main_quit();
	def main(self): gtk.main();
		
if __name__ == "__main__": Window().main()
