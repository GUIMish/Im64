#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#  Copyright: GUIMish <Mish7913@gmail.com>
#  License:   GNU General Public License v2 or later

import os

def lang(code):
	if os.getenv('LANG') == 'uk_UA.UTF-8': return ua(code)
	if os.getenv('LANG') == 'ru_UA.UTF-8': return ru(code)
	if os.getenv('LANG') == 'ru_RU.UTF-8': return ru(code)
	else: return en(code)

def en(code):
	if code == 'FILE': return 'File'
	elif code == 'OPEN': return 'Open'
	elif code == 'EXIT': return 'Exit'
	elif code == 'EDIT': return 'Edit'
	elif code == 'ENCODE': return 'Encode'
	elif code == 'DECODE': return 'Decode'
	elif code == 'HELP': return 'Help'
	elif code == 'ABOUT': return 'About'
	elif code == 'COPY': return 'Copy'
	elif code == 'CLEAR': return 'Clear'
	elif code == 'IMAGES': return 'All Images'
	elif code == 'IMAGE': return 'Image'
	elif code == 'COMMENTS': return 'GNU Encoder\nImages to Base64'
	elif code == 'LICENSE': return 'Im64 - Free software. And licensed under GNU General Public License.'
	else: return ''
    
def ua(code):
	if code == 'FILE': return 'Файл'
	elif code == 'OPEN': return 'Відкрити'
	elif code == 'EXIT': return 'Вийти'
	elif code == 'EDIT': return 'Редагування'
	elif code == 'ENCODE': return 'Шифрувати'
	elif code == 'DECODE': return 'Розкодувати'
	elif code == 'HELP': return 'Допомога'
	elif code == 'ABOUT': return 'Про програму'
	elif code == 'COPY': return 'Копіювати'
	elif code == 'CLEAR': return 'Очистити'
	elif code == 'IMAGES': return 'Усі зображення'
	elif code == 'IMAGE': return 'Зображення'
	elif code == 'COMMENTS': return 'GNU Шифрувальник\nЗображень в Base64'
	elif code == 'LICENSE': return 'Im64 - Вільне програмне забезпечення. поширюється згідно з ліцензією GNU General Public License.'
	else: return ''
    
def ru(code):
	if code == 'FILE': return 'Файл'
	elif code == 'OPEN': return 'Открыть'
	elif code == 'EXIT': return 'Выход'
	elif code == 'EDIT': return 'Правка'
	elif code == 'ENCODE': return 'Кодировать'
	elif code == 'DECODE': return 'Раскодировать'
	elif code == 'HELP': return 'Справка'
	elif code == 'ABOUT': return 'О Программе'
	elif code == 'COPY': return 'Копировать'
	elif code == 'CLEAR': return 'Очистить'
	elif code == 'IMAGES': return 'Все изображения'
	elif code == 'IMAGE': return 'Изображение'
	elif code == 'COMMENTS': return 'GNU Кодировщик\nИзображений в Base64'
	elif code == 'LICENSE': return 'Бесплатно программное обеспечение. И лицензируется в соответствии с GNU General Public License.'
	else: return ''
