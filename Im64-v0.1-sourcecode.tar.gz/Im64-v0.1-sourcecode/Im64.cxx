#include <iostream>
#include <stdio.h>
#include <python2.7/Python.h>

int main(int argc, char **argv)
{
	system("python Im64.pyc");
	return 0;
}

