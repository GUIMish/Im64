#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#  Copyright: GUIMish <Mish7913@gmail.com>
#  License:   GNU General Public License v2 or later

import pygtk; import gtk;  import locale;   import gettext;   import base64
import cairo; import rsvg; import cairosvg; import os;        import lng

pygtk.require("2.0")

class Window:
	def __init__(self):
		AcG = gtk.AccelGroup(); self.UrlT = ''
		
		window = gtk.Window()
		window.set_title("Im64"); 			window.set_resizable(False); 		window.set_position(gtk.WIN_POS_CENTER);
		window.set_border_width(0); 		window.set_size_request(350, 400);  window.set_icon(self.fileicon("./Icon.svg"));
		window.connect("destroy", quit);
		
		vBox = gtk.VBox(False, 0); window.add(vBox);
		
		mMenuBar = gtk.MenuBar();
		
		mMenuFile = gtk.Menu();
		mItemFile = gtk.MenuItem(lng.lang('FILE'));   mItemFile.set_submenu(mMenuFile);
		mItemOpen = gtk.MenuItem(lng.lang('OPEN'));   mMenuFile.append(mItemOpen);
		mItemOpen.connect("activate", self.open);
		mItemSep = gtk.SeparatorMenuItem();           mMenuFile.append(mItemSep);
		mItemExit = gtk.MenuItem(lng.lang('EXIT'));   mMenuFile.append(mItemExit);
		mItemExit.connect("activate", self.quit);
		mMenuBar.append(mItemFile);
		
		mMenuEdit = gtk.Menu();
		mItemEdit = gtk.MenuItem(lng.lang('EDIT'));   mItemEdit.set_submenu(mMenuEdit);
		mItemCopy = gtk.MenuItem(lng.lang('COPY'));   mMenuEdit.append(mItemCopy);
		mItemCopy.connect("activate", self.copy);
		mItemClear = gtk.MenuItem(lng.lang('CLEAR')); mMenuEdit.append(mItemClear);
		mItemClear.connect("activate", self.clear);
		#mItemSep = gtk.SeparatorMenuItem();           mMenuEdit.append(mItemSep);
		#mItemDec = gtk.MenuItem(lng.lang('DECODE'));  mMenuEdit.append(mItemDec);
		#mItemDec.connect("activate", self.decode);
		mMenuBar.append(mItemEdit);
		
		mMenuHelp  = gtk.Menu();
		mItemHelp  = gtk.MenuItem(lng.lang('HELP'));  mItemHelp.set_submenu(mMenuHelp);
		mItemAbout = gtk.MenuItem(lng.lang('ABOUT')); mMenuHelp.append(mItemAbout);
		mItemAbout.connect("activate", self.about);
		mMenuBar.append(mItemHelp);
		
		vBox.pack_start(mMenuBar, False, False, 2);
		
		hBox = gtk.HBox(True, 0);   ImageFrame = gtk.Frame();              hBox.add(ImageFrame);
		self.Image = gtk.Image();   self.Image.set_size_request(35, 35);   ImageFrame.add(self.Image);
		
		hBox.set_border_width(5);                  vBox.add(hBox);
		vBox2 = gtk.VBox(True, 0);                 hBox.add(vBox2);       
		BtnOpen = gtk.Button(lng.lang('OPEN'));    vBox2.add(BtnOpen);   BtnOpen.connect("clicked", self.open); 
		vBox3 = gtk.VBox(True, 0);                 vBox2.add(vBox3);
		BtnEnc = gtk.Button(lng.lang('ENCODE'));   vBox2.add(BtnEnc);    BtnEnc.connect("clicked", self.encode);
		hBox4 = gtk.HBox(True, 0); 		           vBox2.add(hBox4);
		BtnCopy = gtk.Button(lng.lang('COPY'));    hBox4.add(BtnCopy);   BtnCopy.connect("clicked", self.copy);
		BtnClear = gtk.Button(lng.lang('CLEAR'));  hBox4.add(BtnClear);  BtnClear.connect("clicked", self.clear);
		
		ScWin = gtk.ScrolledWindow(); ScWin.set_policy(gtk.POLICY_AUTOMATIC, gtk.POLICY_ALWAYS);  vBox.add(ScWin);
		TextView = gtk.TextView();    ScWin.add(TextView);
		TextView.set_editable(False); TextView.set_wrap_mode(True);  TextView.set_size_request(350, 145);
		self.TextBuffer = TextView.get_buffer(); 
		
		window.show_all();
		
	def about(self, widget, data = None):
		Abdialog = gtk.AboutDialog();
		Abdialog.set_program_name("Im64"); 			     Abdialog.set_version("0.2");
		Abdialog.set_logo(self.fileicon("./Icon.svg"));	 Abdialog.set_authors(("GUIMish <Mish7913@gmail.com>", ""));
		Abdialog.set_copyright("Copyright © Mish7913");  Abdialog.set_comments(lng.lang('COMMENTS'));
		Abdialog.set_website_label("Web-site"); 		 Abdialog.set_website("https://guimish.blogspot.com/2017/03/im64.html");
		Abdialog.set_license(lng.lang('LICENSE'));       Abdialog.run(); Abdialog.destroy();
	def open(self, widget, data = None):
		dialog = gtk.FileChooserDialog("Open..", None, gtk.FILE_CHOOSER_ACTION_OPEN, (gtk.STOCK_CANCEL, gtk.RESPONSE_CANCEL, 
																						   gtk.STOCK_OPEN,   gtk.RESPONSE_OK))
		filter = gtk.FileFilter();
		filter.set_name(lng.lang('IMAGES'));
		filter.add_mime_type("image/png");  filter.add_pattern("*.png");
		filter.add_mime_type("image/jpeg"); filter.add_pattern("*.jpg");
		filter.add_mime_type("image/gif");  filter.add_pattern("*.gif");
		filter.add_mime_type("image/svg");  filter.add_pattern("*.svg");
		dialog.add_filter(filter);
		
		filter = gtk.FileFilter(); filter.set_name(lng.lang('IMAGE')+' PNG (*.png)');
		filter.add_mime_type("image/png");  filter.add_pattern("*.png"); dialog.add_filter(filter);
		filter = gtk.FileFilter(); filter.set_name(lng.lang('IMAGE')+' JPG (*.jpg)');
		filter.add_mime_type("image/jpeg");  filter.add_pattern("*.jpg"); dialog.add_filter(filter);
		filter = gtk.FileFilter(); filter.set_name(lng.lang('IMAGE')+' GIF (*.gif)');
		filter.add_mime_type("image/gif");  filter.add_pattern("*.gif"); dialog.add_filter(filter);
		filter = gtk.FileFilter(); filter.set_name(lng.lang('IMAGE')+' SVG (*.svg)');
		filter.add_mime_type("image/svg");  filter.add_pattern("*.svg"); dialog.add_filter(filter);
		
		if dialog.run() == gtk.RESPONSE_OK:
			Img = self.fileicon(dialog.get_filename()); self.UrlT = str(dialog.get_filename());
			FileName, FileExt = os.path.splitext(dialog.get_filename())
			if FileExt == '.svg': Img, self.UrlT = self.opensvg(dialog.get_filename());
			if Img.get_width() < 150:
				if Img.get_height() < 150: self.Image.set_from_pixbuf(Img)
			else:
				if Img.get_width() > Img.get_height():
					height = int((float(Img.get_height()) / float(Img.get_width())) * 150)
					self.Image.set_from_pixbuf(Img.scale_simple(150, height, gtk.gdk.INTERP_BILINEAR))
				else:
					width = int((float(Img.get_width()) / float(Img.get_height())) * 150)
					self.Image.set_from_pixbuf(Img.scale_simple(width, 150, gtk.gdk.INTERP_BILINEAR))
		dialog.destroy();
	def opensvg(self, file, width = '', height = ''):
		FileImage = self.fileicon(file);
		ImgSur = cairo.ImageSurface(cairo.FORMAT_ARGB32, FileImage.get_width(), FileImage.get_height())
		ctx = cairo.Context(ImgSur); sHandle= rsvg.Handle(file); sHandle.render_cairo(ctx)
		ImgSur.write_to_png("/tmp/Im64_ImportSVG.png")
		return gtk.gdk.pixbuf_new_from_file("/tmp/Im64_ImportSVG.png"), str("/tmp/Im64_ImportSVG.png")
		
	def decode(self, widget, data = None):
		return 0
	def encode(self, widget, data = None):
		self.TextBuffer.set_text('<img src="data:image/png;base64,' + base64.b64encode(open(self.UrlT, "rb").read()) + '" />');
	def copy(self, widget, data = None):
		txBuff = self.TextBuffer.get_text(self.TextBuffer.get_start_iter(), self.TextBuffer.get_end_iter(), True)
		clipboard = gtk.clipboard_get(); clipboard.set_text(txBuff); clipboard.store()
	def fileicon(self, file): return gtk.gdk.pixbuf_new_from_file(file);
	def clear(self, widget, data = None): self.TextBuffer.set_text('');
	def quit(self, widget, data = None): gtk.main_quit();
	def main(self): gtk.main();
		
if __name__ == "__main__": Window().main()
